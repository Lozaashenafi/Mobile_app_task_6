class ServerException implements Exception {} // for API errors

class CacheException implements Exception {} // for local cache errors
